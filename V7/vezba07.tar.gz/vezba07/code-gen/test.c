int a;
int b;

int main() {
 a = 0;

 a = a + 1;

 return a;
}
