
int main(int p) {
  int a;
  int b;

  if(a - 4 >= 4 - p) p = p + 1;
}
